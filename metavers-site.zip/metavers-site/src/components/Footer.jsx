import { Link } from 'react-router-dom'
import { Phone, Mail, MapPin } from 'lucide-react'

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center mb-4">
              <div className="bg-primary text-primary-foreground px-3 py-1 rounded-lg font-bold text-lg">
                Metavers
              </div>
              <span className="ml-2 text-sm text-gray-300">Gestão Expert</span>
            </div>
            <p className="text-gray-300 mb-4 max-w-md">
              Treinamentos corporativos práticos e orientados a resultados. 
              Capacitamos equipes em Atendimento, IA, Liderança, Vendas e Performance.
            </p>
            <div className="space-y-2">
              <div className="flex items-center text-gray-300">
                <Phone className="h-4 w-4 mr-2" />
                <a href="tel:+5511932037368" className="hover:text-white">
                  (11) 93203-7368
                </a>
              </div>
              <div className="flex items-center text-gray-300">
                <Mail className="h-4 w-4 mr-2" />
                <a href="mailto:contato@metaversgestaoexpert.com.br" className="hover:text-white">
                  contato@metaversgestaoexpert.com.br
                </a>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Links Rápidos</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-white transition-colors">
                  Início
                </Link>
              </li>
              <li>
                <Link to="/treinamentos" className="text-gray-300 hover:text-white transition-colors">
                  Treinamentos
                </Link>
              </li>
              <li>
                <Link to="/clientes" className="text-gray-300 hover:text-white transition-colors">
                  Clientes
                </Link>
              </li>
              <li>
                <Link to="/sobre" className="text-gray-300 hover:text-white transition-colors">
                  Sobre
                </Link>
              </li>
              <li>
                <Link to="/contato" className="text-gray-300 hover:text-white transition-colors">
                  Contato
                </Link>
              </li>
            </ul>
          </div>

          {/* Training Areas */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Treinamentos</h3>
            <ul className="space-y-2 text-gray-300">
              <li>Atendimento ao Cliente</li>
              <li>Comandos para IA</li>
              <li>Liderança</li>
              <li>Trabalho em Equipe</li>
              <li>Vendas</li>
              <li>Performance de Equipes</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2025 Metavers Gestão Expert. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  )
}

export default Footer

