import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { 
  Phone, 
  Mail, 
  MessageCircle, 
  Clock,
  MapPin,
  Send,
  CheckCircle
} from 'lucide-react'

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    participants: '',
    interests: [],
    message: ''
  })
  const [isSubmitted, setIsSubmitted] = useState(false)

  const trainingOptions = [
    'Atendimento ao Cliente',
    'Comandos para IA',
    'Liderança',
    'Trabalho em Equipe',
    'Vendas',
    'Performance de Equipes'
  ]

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleInterestChange = (interest, checked) => {
    setFormData(prev => ({
      ...prev,
      interests: checked 
        ? [...prev.interests, interest]
        : prev.interests.filter(i => i !== interest)
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          company: formData.company,
          participants: formData.participants,
          interests: formData.interests.join(", "),
          message: formData.message,
        }),
      })
      
      if (response.ok) {
        setIsSubmitted(true)
        // Reset form
        setFormData({
          name: '',
          email: '',
          phone: '',
          company: '',
          participants: '',
          interests: [],
          message: ''
        })
      } else {
        alert('Erro ao enviar mensagem. Tente novamente.')
      }
    } catch (error) {
      console.error('Error:', error)
      alert('Erro ao enviar mensagem. Tente novamente.')
    }
  }

  if (isSubmitted) {
    return (
      <div className="min-h-screen py-20 flex items-center justify-center">
        <div className="max-w-md mx-auto text-center">
          <div className="mb-6">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-foreground mb-2">Mensagem Enviada!</h2>
            <p className="text-muted-foreground">
              Obrigado pelo seu interesse. Nossa equipe entrará em contato em até 1 dia útil.
            </p>
          </div>
          <Button onClick={() => setIsSubmitted(false)}>
            Enviar Nova Mensagem
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4">
            Fale Conosco
          </Badge>
          <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Vamos conversar sobre seu projeto
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Preencha o formulário abaixo ou entre em contato diretamente. 
            Nossa equipe está pronta para desenhar o treinamento ideal para sua empresa.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Contact Info */}
          <div className="lg:col-span-1">
            <div className="space-y-6">
              {/* Phone */}
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <Phone className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">Telefone</CardTitle>
                      <CardDescription>Ligue agora mesmo</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <a 
                    href="tel:+5511932037368" 
                    className="text-lg font-semibold text-primary hover:underline"
                  >
                    (11) 93203-7368
                  </a>
                </CardContent>
              </Card>

              {/* WhatsApp */}
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-green-100 rounded-lg">
                      <MessageCircle className="h-6 w-6 text-green-600" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">WhatsApp</CardTitle>
                      <CardDescription>Conversa rápida e direta</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Button asChild className="w-full bg-green-600 hover:bg-green-700">
                    <a 
                      href="https://wa.me/5511932037368?text=Olá! Gostaria de saber mais sobre os treinamentos da Metavers."
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <MessageCircle className="mr-2 h-4 w-4" />
                      Abrir WhatsApp
                    </a>
                  </Button>
                </CardContent>
              </Card>

              {/* Email */}
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <Mail className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">E-mail</CardTitle>
                      <CardDescription>Envie sua mensagem</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <a 
                    href="mailto:contato@metaversgestaoexpert.com.br" 
                    className="text-lg font-semibold text-primary hover:underline break-all"
                  >
                    contato@metaversgestaoexpert.com.br
                  </a>
                </CardContent>
              </Card>

              {/* Response Time */}
              <Card className="bg-primary/5">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <Clock className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">Tempo de Resposta</CardTitle>
                      <CardDescription>Respondemos em até 1 dia útil</CardDescription>
                    </div>
                  </div>
                </CardHeader>
              </Card>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Solicitar Proposta</CardTitle>
                <CardDescription>
                  Preencha os dados abaixo e nossa equipe entrará em contato para 
                  desenhar a melhor solução para sua empresa.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Basic Info */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Nome Completo *</Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                        placeholder="Seu nome completo"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">E-mail *</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        placeholder="seu@email.com"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="phone">Telefone/WhatsApp *</Label>
                      <Input
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        required
                        placeholder="(11) 99999-9999"
                      />
                    </div>
                    <div>
                      <Label htmlFor="company">Empresa *</Label>
                      <Input
                        id="company"
                        name="company"
                        value={formData.company}
                        onChange={handleInputChange}
                        required
                        placeholder="Nome da sua empresa"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="participants">Número de Participantes</Label>
                    <Input
                      id="participants"
                      name="participants"
                      value={formData.participants}
                      onChange={handleInputChange}
                      placeholder="Ex: 10-15 pessoas"
                    />
                  </div>

                  {/* Training Interests */}
                  <div>
                    <Label className="text-base font-medium mb-4 block">
                      Treinamentos de Interesse
                    </Label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {trainingOptions.map((option) => (
                        <div key={option} className="flex items-center space-x-2">
                          <Checkbox
                            id={option}
                            checked={formData.interests.includes(option)}
                            onCheckedChange={(checked) => handleInterestChange(option, checked)}
                          />
                          <Label htmlFor={option} className="text-sm font-normal">
                            {option}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Message */}
                  <div>
                    <Label htmlFor="message">Mensagem</Label>
                    <Textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      placeholder="Conte-nos mais sobre suas necessidades, desafios atuais ou objetivos específicos..."
                      rows={4}
                    />
                  </div>

                  {/* Submit Button */}
                  <Button type="submit" size="lg" className="w-full">
                    <Send className="mr-2 h-4 w-4" />
                    Enviar Solicitação
                  </Button>

                  <p className="text-sm text-muted-foreground text-center">
                    * Campos obrigatórios. Seus dados estão seguros conosco.
                  </p>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Additional Info */}
        <div className="mt-20 text-center p-12 bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            Próximos Passos
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8">
            <div className="text-center">
              <div className="bg-primary text-primary-foreground w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4">
                1
              </div>
              <h3 className="font-semibold mb-2">Análise da Demanda</h3>
              <p className="text-muted-foreground text-sm">
                Analisamos suas necessidades e objetivos específicos
              </p>
            </div>
            <div className="text-center">
              <div className="bg-primary text-primary-foreground w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4">
                2
              </div>
              <h3 className="font-semibold mb-2">Proposta Customizada</h3>
              <p className="text-muted-foreground text-sm">
                Criamos uma proposta sob medida para sua empresa
              </p>
            </div>
            <div className="text-center">
              <div className="bg-primary text-primary-foreground w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4">
                3
              </div>
              <h3 className="font-semibold mb-2">Execução do Projeto</h3>
              <p className="text-muted-foreground text-sm">
                Implementamos o treinamento e acompanhamos os resultados
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Contact

