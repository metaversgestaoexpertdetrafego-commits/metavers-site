import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Link } from 'react-router-dom'
import { 
  Target, 
  Users, 
  Lightbulb, 
  TrendingUp,
  CheckCircle,
  ArrowRight,
  Award,
  BookOpen,
  Zap
} from 'lucide-react'

const About = () => {
  const differentials = [
    {
      icon: Target,
      title: 'Customização por Segmento',
      description: 'Adaptamos cada treinamento às especificidades do seu setor e necessidades reais do negócio.'
    },
    {
      icon: Users,
      title: 'Instrutores Praticantes',
      description: 'Nossa equipe é formada por profissionais com experiência real de mercado, não apenas teoria.'
    },
    {
      icon: BookOpen,
      title: 'Conteúdo Baseado em Evidências',
      description: 'Metodologias comprovadas e atualizadas com as melhores práticas do mercado.'
    },
    {
      icon: Zap,
      title: 'Aplicação Imediata',
      description: 'Conteúdo prático que pode ser aplicado em 24-48h no dia a dia da sua equipe.'
    }
  ]

  const methodology = [
    {
      step: '01',
      title: 'Diagnóstico',
      description: 'Análise detalhada das necessidades, desafios e objetivos da sua equipe.',
      color: 'bg-blue-500'
    },
    {
      step: '02',
      title: 'Desenho da Jornada',
      description: 'Criação de programa personalizado com metodologia e cronograma específicos.',
      color: 'bg-purple-500'
    },
    {
      step: '03',
      title: 'Prática Guiada',
      description: 'Execução do treinamento com exercícios práticos e simulações reais.',
      color: 'bg-green-500'
    },
    {
      step: '04',
      title: 'Mensuração de Resultados',
      description: 'Acompanhamento de indicadores e ajustes para garantir o ROI do investimento.',
      color: 'bg-orange-500'
    }
  ]

  const values = [
    {
      title: 'Excelência',
      description: 'Buscamos sempre a mais alta qualidade em nossos treinamentos e resultados.'
    },
    {
      title: 'Praticidade',
      description: 'Focamos em soluções aplicáveis e que geram impacto real no dia a dia.'
    },
    {
      title: 'Inovação',
      description: 'Incorporamos as mais recentes tendências e tecnologias em nossos programas.'
    },
    {
      title: 'Parceria',
      description: 'Construímos relacionamentos duradouros baseados em confiança e resultados.'
    }
  ]

  return (
    <div className="min-h-screen py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4">
            Sobre Nós
          </Badge>
          <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Transformando empresas através de pessoas
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            A Metavers Gestão Expert evoluiu de agência de marketing digital para se tornar 
            referência em treinamentos corporativos que geram resultados reais.
          </p>
        </div>

        {/* Company Story */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
          <div>
            <h2 className="text-3xl font-bold mb-6">Nossa História</h2>
            <div className="space-y-4 text-muted-foreground">
              <p>
                Fundada como uma agência de publicidade especializada em gestão de tráfego, 
                a Metavers sempre teve o foco em gerar resultados concretos para nossos clientes.
              </p>
              <p>
                Ao longo dos anos, percebemos que o maior diferencial das empresas de sucesso 
                não estava apenas nas estratégias de marketing, mas na qualidade e preparação 
                de suas equipes.
              </p>
              <p>
                Essa percepção nos levou a uma transformação natural: de agência para hub de 
                treinamento e desenvolvimento de performance. Hoje, combinamos nossa experiência 
                em resultados com metodologias de capacitação comprovadas.
              </p>
            </div>
          </div>
          <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl p-8 lg:p-12">
            <h3 className="text-2xl font-bold mb-6">Nossa Missão</h3>
            <p className="text-lg text-muted-foreground mb-6">
              Capacitar equipes com treinamentos práticos que transformam conhecimento em 
              resultados mensuráveis, elevando a performance individual e coletiva.
            </p>
            <h3 className="text-2xl font-bold mb-6">Nossa Visão</h3>
            <p className="text-lg text-muted-foreground">
              Ser a principal referência em treinamentos corporativos no Brasil, 
              reconhecida pela qualidade, praticidade e impacto real nos negócios.
            </p>
          </div>
        </div>

        {/* Differentials */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center mb-12">Nossos Diferenciais</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {differentials.map((differential, index) => {
              const IconComponent = differential.icon
              return (
                <Card key={index} className="text-center">
                  <CardHeader>
                    <div className="mx-auto mb-4 p-3 bg-primary/10 rounded-full w-fit">
                      <IconComponent className="h-8 w-8 text-primary" />
                    </div>
                    <CardTitle className="text-lg">{differential.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base">
                      {differential.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>

        {/* Methodology */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center mb-12">Nossa Metodologia</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {methodology.map((step, index) => (
              <div key={index} className="relative">
                <Card className="h-full">
                  <CardHeader>
                    <div className={`${step.color} text-white w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg mb-4`}>
                      {step.step}
                    </div>
                    <CardTitle className="text-lg">{step.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base">
                      {step.description}
                    </CardDescription>
                  </CardContent>
                </Card>
                {index < methodology.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                    <ArrowRight className="h-6 w-6 text-muted-foreground" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Values */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center mb-12">Nossos Valores</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <CheckCircle className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">{value.title}</h3>
                    <p className="text-muted-foreground">{value.description}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Credentials */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center mb-12">Credenciais e Experiência</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center p-8">
              <Award className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Certificações</h3>
              <p className="text-muted-foreground">
                Instrutores certificados em metodologias de treinamento e desenvolvimento humano.
              </p>
            </Card>
            <Card className="text-center p-8">
              <TrendingUp className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Experiência Comprovada</h3>
              <p className="text-muted-foreground">
                Mais de 5 anos atuando com empresas de diversos segmentos e portes.
              </p>
            </Card>
            <Card className="text-center p-8">
              <Lightbulb className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Inovação Constante</h3>
              <p className="text-muted-foreground">
                Sempre atualizados com as últimas tendências em capacitação e tecnologia.
              </p>
            </Card>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center p-12 bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            Vamos transformar sua equipe juntos?
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Converse com nossos especialistas e descubra como nossos treinamentos 
            podem elevar a performance da sua empresa.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild>
              <Link to="/contato">
                Falar com Especialista
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link to="/treinamentos">
                Ver Nossos Treinamentos
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default About

