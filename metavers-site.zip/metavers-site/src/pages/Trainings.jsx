import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Users, 
  Brain, 
  Crown, 
  Handshake, 
  TrendingUp, 
  Target,
  Clock,
  Users2,
  Download,
  ArrowRight
} from 'lucide-react'

const Trainings = () => {
  const trainings = [
    {
      id: 'atendimento',
      icon: Users,
      title: 'Atendimento ao Cliente',
      objective: 'Padronizar e elevar a experiência do cliente em todos os canais.',
      audience: 'Times de SAC, suporte, recepção, pré e pós-venda.',
      format: 'Workshop prático (4h/8h), imersão (16h) ou programa contínuo.',
      topics: [
        'Comunicação empática e assertiva',
        'Mapeamento de jornada do cliente',
        'Scripts e tratamento de objeções',
        'Métricas NPS/CSAT',
        'Atendimento omnichannel'
      ],
      results: 'Redução de retrabalho, aumento de satisfação e retenção de clientes.',
      color: 'bg-blue-500'
    },
    {
      id: 'ia',
      icon: Brain,
      title: 'Comandos para IA (Prompt Engineering)',
      objective: 'Ensinar times a obterem respostas de alta qualidade de ferramentas de IA para acelerar rotinas.',
      audience: 'Marketing, vendas, atendimento, operações e liderança.',
      format: 'Workshop prático (4h) ou curso intensivo (8h).',
      topics: [
        'Estrutura de prompts eficazes',
        'Criação de personas para IA',
        'Cadeias de prompts complexos',
        'Revisão crítica de resultados',
        'Ética e privacidade em IA'
      ],
      results: 'Redução de 60% no tempo de criação de conteúdo e análises.',
      color: 'bg-purple-500',
      cases: [
        'Criação de ofertas personalizadas',
        'Roteiros de atendimento',
        'Análises de dados',
        'E-mails e comunicações'
      ]
    },
    {
      id: 'lideranca',
      icon: Crown,
      title: 'Liderança',
      objective: 'Desenvolver líderes capazes de conduzir pessoas e processos com consistência.',
      audience: 'Gestores, supervisores e líderes de equipe.',
      format: 'Programa de desenvolvimento (16h-32h) ou mentoria individual.',
      topics: [
        'Estilos de liderança situacional',
        'Comunicação assertiva',
        'Feedback e conversas 1:1',
        'Gestão de metas e resultados',
        'Rituais de time e engajamento'
      ],
      results: 'Melhoria de 40% no engajamento e produtividade das equipes.',
      color: 'bg-yellow-500'
    },
    {
      id: 'equipe',
      icon: Handshake,
      title: 'Trabalho em Equipe',
      objective: 'Fortalecer colaboração e accountability entre membros do time.',
      audience: 'Equipes multidisciplinares e times de projeto.',
      format: 'Workshop colaborativo (8h) ou programa de team building.',
      topics: [
        'Alinhamento de objetivos comuns',
        'Definição de papéis e responsabilidades',
        'Tomada de decisão colaborativa',
        'Rituais de colaboração',
        'Resolução de conflitos'
      ],
      results: 'Redução de 50% em conflitos internos e aumento da sinergia.',
      color: 'bg-green-500'
    },
    {
      id: 'vendas',
      icon: TrendingUp,
      title: 'Vendas',
      objective: 'Aumentar conversão e ticket médio com técnicas comprovadas.',
      audience: 'Equipes comerciais, SDRs, vendedores e gerentes de venda.',
      format: 'Treinamento intensivo (16h) ou programa de aceleração (32h).',
      topics: [
        'Prospecção e qualificação',
        'Diagnóstico de necessidades',
        'Proposta de valor diferenciada',
        'Técnicas de negociação',
        'Follow-up e gestão de CRM'
      ],
      results: 'Aumento de 35% na conversão e 25% no ticket médio.',
      color: 'bg-red-500'
    },
    {
      id: 'performance',
      icon: Target,
      title: 'Performance de Equipes',
      objective: 'Elevar produtividade com dados e rituais de melhoria contínua.',
      audience: 'Líderes, gestores e equipes de alta performance.',
      format: 'Programa de transformação (24h) ou consultoria aplicada.',
      topics: [
        'Implementação de OKRs/KPIs',
        'Cadência de execução',
        'Priorização estratégica',
        'Ritos semanais de acompanhamento',
        'Retrospectivas e melhoria contínua'
      ],
      results: 'Melhoria de 50% na produtividade e atingimento de metas.',
      color: 'bg-indigo-500'
    }
  ]

  return (
    <div className="min-h-screen py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4">
            Nossos Treinamentos
          </Badge>
          <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Escolha a trilha ideal para o seu objetivo
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Treinamentos práticos e customizados para transformar a performance do seu time. 
            Cada programa é desenhado com base em metodologias comprovadas e experiência real de mercado.
          </p>
        </div>

        {/* Training Cards */}
        <div className="space-y-12">
          {trainings.map((training, index) => {
            const IconComponent = training.icon
            return (
              <Card key={training.id} id={training.id} className="overflow-hidden">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-0">
                  {/* Left Column - Header */}
                  <div className={`${training.color} text-white p-8 lg:p-12`}>
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="p-3 bg-white/20 rounded-lg">
                        <IconComponent className="h-8 w-8" />
                      </div>
                      <div>
                        <h2 className="text-2xl font-bold">{training.title}</h2>
                      </div>
                    </div>
                    <p className="text-lg opacity-90 mb-6">{training.objective}</p>
                    
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center">
                          <Users2 className="h-4 w-4 mr-2" />
                          Para quem:
                        </h4>
                        <p className="text-sm opacity-90">{training.audience}</p>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center">
                          <Clock className="h-4 w-4 mr-2" />
                          Formato:
                        </h4>
                        <p className="text-sm opacity-90">{training.format}</p>
                      </div>
                    </div>
                  </div>

                  {/* Middle Column - Content */}
                  <div className="p-8 lg:p-12 lg:col-span-2">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {/* Topics */}
                      <div>
                        <h3 className="text-lg font-semibold mb-4 text-foreground">
                          Tópicos Principais:
                        </h3>
                        <ul className="space-y-2">
                          {training.topics.map((topic, topicIndex) => (
                            <li key={topicIndex} className="flex items-start">
                              <div className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0"></div>
                              <span className="text-muted-foreground">{topic}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Results & Cases */}
                      <div className="space-y-6">
                        <div>
                          <h3 className="text-lg font-semibold mb-4 text-foreground">
                            Resultados Esperados:
                          </h3>
                          <p className="text-muted-foreground">{training.results}</p>
                        </div>

                        {training.cases && (
                          <div>
                            <h3 className="text-lg font-semibold mb-4 text-foreground">
                              Casos Práticos:
                            </h3>
                            <ul className="space-y-2">
                              {training.cases.map((case_, caseIndex) => (
                                <li key={caseIndex} className="flex items-start">
                                  <div className="w-2 h-2 bg-accent rounded-full mt-2 mr-3 flex-shrink-0"></div>
                                  <span className="text-muted-foreground">{case_}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {/* CTAs */}
                        <div className="flex flex-col sm:flex-row gap-3 pt-4">
                          <Button size="sm" asChild>
                            <Link to="/contato">
                              Solicitar Proposta
                              <ArrowRight className="ml-2 h-3 w-3" />
                            </Link>
                          </Button>
                          <Button size="sm" variant="outline">
                            <Download className="mr-2 h-3 w-3" />
                            Baixar Ementa
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            )
          })}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-20 p-12 bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            Não encontrou o que procura?
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Criamos treinamentos customizados para atender às necessidades específicas da sua empresa.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild>
              <Link to="/contato">
                Falar com Especialista
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <a href="tel:+5511993642094">
                Ligar: (11) 99364-2094
              </a>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Trainings

