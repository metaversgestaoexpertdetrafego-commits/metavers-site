import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Link } from 'react-router-dom'
import { 
  Building2, 
  Banknote, 
  Home, 
  Hammer, 
  UtensilsCrossed, 
  Stethoscope,
  Scale,
  Gem,
  Calendar,
  Sun,
  Shield,
  Car,
  Star,
  Quote,
  ArrowRight,
  Users,
  TrendingUp,
  Award
} from 'lucide-react'

// Import training feedback images
import trainingImage1 from '../assets/WhatsAppImage2025-08-20at10.54.53.jpeg'
import trainingImage2 from '../assets/WhatsAppImage2025-08-20at11.02.08.jpeg'
import trainingImage3 from '../assets/WhatsAppImage2025-08-20at11.05.29.jpeg'
import trainingImage4 from '../assets/WhatsAppImage2025-08-20at11.05.34(2).jpeg'
import trainingImage5 from '../assets/WhatsAppImage2025-08-20at11.05.34(1).jpeg'
import trainingImage6 from '../assets/WhatsAppImage2025-08-20at11.05.34.jpeg'
import trainingImage7 from '../assets/WhatsAppImage2025-08-20at11.05.35.jpeg'
import trainingImage8 from '../assets/WhatsAppImage2025-08-20at11.05.36.jpeg'
import trainingImage9 from '../assets/WhatsAppImage2025-08-20at11.05.37.jpeg'
import trainingImage10 from '../assets/WhatsAppImage2025-08-20at11.05.38(1).jpeg'
import trainingImage11 from '../assets/WhatsAppImage2025-08-20at11.05.38.jpeg'
import trainingImage12 from '../assets/WhatsAppImage2025-08-20at11.05.39.jpeg'

const Clients = () => {
  const trainingImages = [
    { src: trainingImage1, alt: "Equipe Boca do Lobo - Treinamento de Atendimento" },
    { src: trainingImage2, alt: "Treinamento em Incorporadora - Vendas" },
    { src: trainingImage3, alt: "Treinamento de Equipe - Sala de Reunião" },
    { src: trainingImage4, alt: "Treinamento de IA - Comandos e Prompts" },
    { src: trainingImage5, alt: "Workshop de Liderança" },
    { src: trainingImage6, alt: "Treinamento Prático de Performance" },
    { src: trainingImage7, alt: "Equipe Boca do Lobo - Resultado do Treinamento" },
    { src: trainingImage8, alt: "Treinamento Imobiliário - Equipe de Vendas" },
    { src: trainingImage9, alt: "Grande Grupo - Treinamento Corporativo" },
    { src: trainingImage10, alt: "Aplicação Prática - Uso de Tecnologia" },
    { src: trainingImage11, alt: "Treinamento Personalizado - Consultoria" },
    { src: trainingImage12, alt: "Equipe Completa - Encerramento do Treinamento" }
  ]

  const segments = [
    { name: 'Imobiliárias', icon: Building2, color: 'bg-blue-500' },
    { name: 'Financeiras', icon: Banknote, color: 'bg-green-500' },
    { name: 'Incorporadoras', icon: Home, color: 'bg-purple-500' },
    { name: 'Construtoras', icon: Hammer, color: 'bg-orange-500' },
    { name: 'Restaurantes', icon: UtensilsCrossed, color: 'bg-red-500' },
    { name: 'Médicos', icon: Stethoscope, color: 'bg-teal-500' },
    { name: 'Advogados', icon: Scale, color: 'bg-indigo-500' },
    { name: 'Marmorarias', icon: Gem, color: 'bg-gray-500' },
    { name: 'Eventos', icon: Calendar, color: 'bg-pink-500' },
    { name: 'Energia Solar', icon: Sun, color: 'bg-yellow-500' },
    { name: 'Seguradoras', icon: Shield, color: 'bg-cyan-500' },
    { name: 'Concessionárias', icon: Car, color: 'bg-slate-500' }
  ]

  const testimonials = [
    {
      name: 'Maria Silva',
      role: 'Diretora Comercial',
      company: 'Imobiliária Premium',
      content: 'O treinamento de vendas da Metavers transformou nossa equipe. Aumentamos nossa conversão em 40% em apenas 3 meses.',
      rating: 5
    },
    {
      name: 'João Santos',
      role: 'Gerente de Atendimento',
      company: 'Financeira Crescer',
      content: 'Excelente metodologia! O treinamento de atendimento ao cliente elevou nosso NPS de 7.2 para 8.9.',
      rating: 5
    },
    {
      name: 'Ana Costa',
      role: 'CEO',
      company: 'Construtora Moderna',
      content: 'O programa de liderança desenvolveu nossos gestores de forma prática. Recomendo para qualquer empresa que busca crescimento.',
      rating: 5
    },
    {
      name: 'Carlos Oliveira',
      role: 'Diretor de Marketing',
      company: 'Energia Solar Plus',
      content: 'O treinamento de comandos para IA revolucionou nossa produtividade. Criamos campanhas 60% mais rápido agora.',
      rating: 5
    },
    {
      name: 'Fernanda Lima',
      role: 'Gerente de RH',
      company: 'Grupo Hospitalar',
      content: 'Treinamento de equipe excepcional. Melhorou significativamente a colaboração entre nossos departamentos.',
      rating: 5
    },
    {
      name: 'Roberto Mendes',
      role: 'Sócio-Diretor',
      company: 'Escritório de Advocacia',
      content: 'Performance de equipes foi um divisor de águas. Implementamos OKRs e nossa produtividade disparou.',
      rating: 5
    }
  ]

  const stats = [
    { number: '500+', label: 'Profissionais Treinados' },
    { number: '50+', label: 'Empresas Atendidas' },
    { number: '12', label: 'Segmentos de Mercado' },
    { number: '95%', label: 'Satisfação dos Clientes' }
  ]

  return (
    <div className="min-h-screen py-20">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4 text-blue-600 border-blue-200">
            Nossos Clientes
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Construindo histórias de sucesso
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Estamos construindo histórias de sucesso juntos. Para nós, não há resultado eficiente 
            sem que a performance da sua equipe seja transformada. Cada treinamento é uma parceria 
            para alcançar a excelência.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-20">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-primary mb-2">
                {stat.number}
              </div>
              <div className="text-muted-foreground font-medium">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Training Feedback Gallery */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Feedbacks dos Nossos Treinamentos
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Momentos reais dos nossos treinamentos. Veja como transformamos equipes 
              através de capacitações práticas e orientadas a resultados.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {trainingImages.map((image, index) => (
              <div key={index} className="group relative overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-all duration-300">
                <img 
                  src={image.src} 
                  alt={image.alt}
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-4 left-4 right-4">
                    <p className="text-white text-sm font-medium">{image.alt}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Segments */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center mb-12">Segmentos Atendidos</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {segments.map((segment, index) => {
              const IconComponent = segment.icon
              return (
                <Card key={index} className="group hover:shadow-lg transition-all duration-300 cursor-pointer">
                  <CardHeader className="text-center pb-4">
                    <div className={`${segment.color} w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}>
                      <IconComponent className="h-8 w-8 text-white" />
                    </div>
                    <CardTitle className="text-lg">{segment.name}</CardTitle>
                  </CardHeader>
                </Card>
              )
            })}
          </div>
        </div>

        {/* Testimonials */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center mb-12">O que nossos clientes dizem</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="relative">
                <CardHeader>
                  <div className="flex items-center space-x-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <Quote className="h-8 w-8 text-primary/20 absolute top-4 right-4" />
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-6 italic">
                    "{testimonial.content}"
                  </p>
                  <div>
                    <div className="font-semibold text-foreground">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                    <div className="text-sm text-primary font-medium">{testimonial.company}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Case Studies Preview */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center mb-12">Casos de Sucesso</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card className="p-8">
              <div className="flex items-center space-x-3 mb-4">
                <div className="bg-green-500 w-12 h-12 rounded-full flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Imobiliária Premium</h3>
                  <p className="text-muted-foreground">Treinamento de Vendas</p>
                </div>
              </div>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">+40%</div>
                    <div className="text-sm text-muted-foreground">Conversão</div>
                  </div>
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">+25%</div>
                    <div className="text-sm text-muted-foreground">Ticket Médio</div>
                  </div>
                </div>
                <p className="text-muted-foreground">
                  Implementação de metodologia de vendas consultiva resultou em crescimento 
                  significativo dos indicadores comerciais em apenas 3 meses.
                </p>
              </div>
            </Card>

            <Card className="p-8">
              <div className="flex items-center space-x-3 mb-4">
                <div className="bg-blue-500 w-12 h-12 rounded-full flex items-center justify-center">
                  <Users className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Financeira Crescer</h3>
                  <p className="text-muted-foreground">Treinamento de Atendimento</p>
                </div>
              </div>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">8.9</div>
                    <div className="text-sm text-muted-foreground">NPS Final</div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">-40%</div>
                    <div className="text-sm text-muted-foreground">Tempo Atendimento</div>
                  </div>
                </div>
                <p className="text-muted-foreground">
                  Padronização do atendimento e implementação de scripts empáticos 
                  elevaram drasticamente a satisfação dos clientes.
                </p>
              </div>
            </Card>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center p-12 bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            Sua empresa pode ser a próxima
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Junte-se às empresas que já transformaram seus resultados com nossos treinamentos. 
            Vamos conversar sobre como podemos ajudar o seu negócio.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild>
              <Link to="/contato">
                Solicitar Proposta
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <a href="tel:+5511993642094">
                Ligar: (11) 99364-2094
              </a>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Clients

