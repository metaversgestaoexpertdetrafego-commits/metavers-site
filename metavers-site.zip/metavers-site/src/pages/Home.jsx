import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Users, 
  Brain, 
  Crown, 
  Handshake, 
  TrendingUp, 
  Target,
  CheckCircle,
  ArrowRight,
  Star
} from 'lucide-react'

// Import images
import trainingTeamImg from '../assets/uITu3l2UuFcp.jpeg'
import trainingLeadershipImg from '../assets/7PTrzYKibUT1.png'
import trainingSalesImg from '../assets/v1Qy1mpySN1Y.png'

const Home = () => {
  const trainingHighlights = [
    {
      icon: Users,
      title: 'Atendimento ao Cliente',
      description: 'Padronize e eleve a experiência do cliente em todos os canais',
      image: trainingTeamImg,
      link: '/treinamentos#atendimento'
    },
    {
      icon: Brain,
      title: 'Comandos para IA',
      description: 'Domine prompts para acelerar rotinas com inteligência artificial',
      image: '../assets/E7Ji2F2xUB1f.jpg',
      link: '/treinamentos#ia'
    },
    {
      icon: Crown,
      title: 'Liderança',
      description: 'Desenvolva líderes capazes de conduzir pessoas e processos',
      image: trainingLeadershipImg,
      link: '/treinamentos#lideranca'
    },
    {
      icon: Handshake,
      title: 'Trabalho em Equipe',
      description: 'Fortaleça colaboração e accountability entre times',
      image: trainingTeamImg,
      link: '/treinamentos#equipe'
    },
    {
      icon: TrendingUp,
      title: 'Vendas',
      description: 'Aumente conversão e ticket médio com técnicas comprovadas',
      image: trainingSalesImg,
      link: '/treinamentos#vendas'
    },
    {
      icon: Target,
      title: 'Performance de Equipes',
      description: 'Eleve produtividade com dados e melhoria contínua',
      image: '../assets/LaX8Q9wDFMAb.jpg',
      link: '/treinamentos#performance'
    }
  ]

  const valueProps = [
    {
      title: 'Metodologia Prática',
      description: 'Conteúdo aplicável em 24-48h no seu dia a dia'
    },
    {
      title: 'Instrutores Experientes',
      description: 'Profissionais com vivência real de mercado'
    },
    {
      title: 'Customização Total',
      description: 'Treinamentos adaptados ao seu segmento e necessidades'
    }
  ]

  const results = [
    'Aumento de 35% na satisfação do cliente (NPS)',
    'Redução de 40% no tempo de atendimento',
    'Crescimento de 25% no ticket médio',
    'Melhoria de 50% na produtividade das equipes'
  ]

  const clientSegments = [
    'Imobiliárias', 'Financeiras', 'Incorporadoras', 'Construtoras',
    'Restaurantes', 'Médicos', 'Advogados', 'Marmorarias',
    'Eventos', 'Energia Solar', 'Seguradoras', 'Concessionárias'
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary/10 via-background to-accent/5 py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <Badge variant="secondary" className="mb-4">
              Treinamentos Corporativos
            </Badge>
            <h1 className="text-4xl lg:text-6xl font-bold text-foreground mb-6">
              Treinamentos que elevam a{' '}
              <span className="text-primary">performance</span> do seu time
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              Capacitações práticas em Atendimento, IA, Liderança, Vendas e Alta Performance. 
              Do planejamento à execução, para resultados reais.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link to="/contato">
                  Solicitar Proposta
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/treinamentos">Ver Treinamentos</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Value Props */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {valueProps.map((prop, index) => (
              <Card key={index} className="text-center border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-lg">{prop.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {prop.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Training Highlights */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Treinamentos em Destaque
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Escolha a trilha ideal para o seu objetivo e transforme a performance do seu time
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {trainingHighlights.map((training, index) => {
              const IconComponent = training.icon
              return (
                <Card key={index} className="group hover:shadow-lg transition-all duration-300 cursor-pointer">
                  <CardHeader>
                    <div className="flex items-center space-x-3 mb-2">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <IconComponent className="h-6 w-6 text-primary" />
                      </div>
                      <CardTitle className="text-lg">{training.title}</CardTitle>
                    </div>
                    <CardDescription className="text-base">
                      {training.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button variant="outline" size="sm" asChild>
                      <Link to={training.link}>
                        Ver Ementa
                        <ArrowRight className="ml-2 h-3 w-3" />
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <div className="text-center mt-12">
            <Button size="lg" asChild>
              <Link to="/treinamentos">
                Ver Todos os Treinamentos
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Results Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Resultados Comprovados
            </h2>
            <p className="text-xl opacity-90 max-w-2xl mx-auto">
              Nossos treinamentos geram impacto real nos indicadores do seu negócio
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {results.map((result, index) => (
              <div key={index} className="flex items-center space-x-3">
                <CheckCircle className="h-6 w-6 text-green-300 flex-shrink-0" />
                <span className="text-lg">{result}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Client Segments */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Segmentos Atendidos
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Experiência comprovada em diversos setores da economia
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {clientSegments.map((segment, index) => (
              <div key={index} className="text-center p-4 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors">
                <span className="text-sm font-medium text-foreground">{segment}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary to-accent text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Pronto para treinar seu time?
          </h2>
          <p className="text-xl opacity-90 mb-8">
            Vamos conversar sobre como nossos treinamentos podem transformar a performance da sua empresa.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <Link to="/contato">
                Solicitar Proposta
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary" asChild>
              <a href="tel:+5511993642094">
                Ligar Agora: (11) 99364-2094
              </a>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Home

